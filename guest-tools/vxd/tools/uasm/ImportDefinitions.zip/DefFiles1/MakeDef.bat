lib2def G:\masm32\lib\*.lib

del bhsupp.def
del dpserial.def
del dpwsock.def
del dststlog.def
del kernl32p.def
del masm32.def
