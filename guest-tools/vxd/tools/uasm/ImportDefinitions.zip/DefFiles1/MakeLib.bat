def2lib *.def

def2lib ntvdm.def -e